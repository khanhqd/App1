import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  TextInput,
  Button,
  Alert,
  Scrollview,
  ListView
} from 'react-native';
var URL = "http://192.168.1.41/API/demoapi.php";
var {height, width} = Dimensions.get('window');
const onButtonPress = () => {
  Alert.alert('Button has been pressed!');
};
export default class Data extends Component {
  constructor(props){
    super(props);
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {
      dataSource: ds.cloneWithRows(['row 1', 'row 2']),
      salerName: ""
    }
  }
  fetchData(){
      fetch(URL, {method:'POST' , body: null})
        .then((response) => response.json())
        .then((responseData) =>{
            this.setState({
              dataSource: this.state.dataSource.cloneWithRows(responseData)
            })
        })
      .done()
  };
  taoHang(data) {
    return(
      <View>
        <Text>{data.makh}</Text>
      </View>
    )
  }
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.box}>
          <View style={styles.titleContainer}>
            <Text style={styles.textDauMuc}>
              Mã:
            </Text>
          </View>
          <Text style={styles.text}>
            {this.state.makh}
          </Text>
        </View>
        <ListView
          dataSource={this.state.dataSource}
          renderRow={(data) => this.taoHang(data)}
        />
        <View style={styles.box}>
          <View style={styles.titleContainer}>
            <Text style={styles.textDauMuc}>
              Họ và tên:
            </Text>
          </View>
          <Text style={styles.text}>

          </Text>
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
            <Text style={styles.textDauMuc}>
              Ngày sinh:
            </Text>
          </View>
          <Text style={styles.text}>

          </Text>
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
            <Text style={styles.textDauMuc}>
              Địa chỉ:
            </Text>
          </View>
          <Text style={styles.text}>

          </Text>
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
            <Text style={styles.textDauMuc}>
              Số điện thoại:
            </Text>
          </View>
          <Text style={styles.text}>

          </Text>
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
              <Text style={styles.textDauMuc}>
                Nhân viên phụ trách
              </Text>
          </View>
              <TextInput
                style={{height: 30, borderColor: '#d6d7da', borderWidth: 0.5, paddingLeft:30, fontSize:13}}
                onChangeText={(salerName) => this.setState({salerName})}
                value={this.state.salerName}
                placeholder="Oanh/Dinh/Hạnh/Môi/Linh"
              />
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
              <Text style={styles.textDauMuc}>
                Trạng thái:
              </Text>
          </View>
              <TextInput
                style={{height: 30, borderColor: '#d6d7da', borderWidth: 0.5, paddingLeft:30, fontSize:13}}
                onChangeText={(salerName) => this.setState({salerName})}
                value={this.state.salerName}
                placeholder="Đã hẹn/Đã demo/K thành công"
              />
        </View>

        <View style={styles.box}>
          <View style={styles.titleContainer}>
              <Text style={styles.textDauMuc}>
                Kết quả liên hệ:
              </Text>
          </View>
              <TextInput
                style={{height: 70, borderColor: '#d6d7da', borderWidth: 0.5, paddingLeft:30, fontSize:13}}
                onChangeText={(salerName) => this.setState({salerName})}
                value={this.state.salerName}
                placeholder="Đã hẹn/Đã demo/K thành công"
              />
        </View>
        <View style={{flexDirection:'row', justifyContent:'space-around', backgroundColor:'#ffffff'}}>
          <Button
            onPress={onButtonPress}
            title="Quay lại"
            color="green"
            />
          <Button
            onPress={onButtonPress}
            title="Tiếp tục"
            color="green"
          />
        </View>
      </View>
    );
  }
  componentDidMount(){
      this.fetchData()
  }
}
const styles = StyleSheet.create({

  container:{
    backgroundColor: '#e9eaed',
    flex: 1,
    justifyContent:'space-around'
  },
  box:{
    borderRadius: 3,
    borderWidth: 0.5,
    borderColor: '#d6d7da',
    backgroundColor: '#ffffff',
    margin: 5,
    marginVertical: 1,
    overflow: 'hidden',

  },
  titleContainer:{
    borderBottomWidth: 0.5,
    borderTopLeftRadius: 3,
    borderTopRightRadius: 2.5,
    borderBottomColor: '#d6d7da',
    backgroundColor: '#f6f7f8',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  picker: {
    width: 100,
    height:50
  },
  textDauMuc:{
    color:'black',
    paddingLeft:20,
    fontSize:13,
    fontWeight:'bold'
  },
  text:{
    fontSize:13,
    padding:10,
    paddingLeft:30
  },
});
